package main;

public interface Beverage {


    // all are the abstract methods.
    void getCost(String s);

    void getDescription(String Coffee);
}


